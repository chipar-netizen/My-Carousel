# Allura Dental — Design System

A brand + product design system for **Allura Dental**, a modern dental practice in Truganina, VIC, operated (arms-length) by **PCP Corporates Pty Ltd** under the proposed trading name **The Good Clinics Co.** This system packages the locked brand identity, colour and type foundations, real logo/badge/icon assets, reusable UI components, and a recreation of the marketing website so designers and agents can produce on-brand work quickly.

> **Positioning in one line:** *Modern dentistry, done differently.* **Values lockup:** Honest · Quality · Care.

---

## Business context

- **PCP Corporates Pty Ltd** — the operating company (clinic enablement, operations, digital marketing). Proposed broader trading name: **The Good Practice Network.** (not yet registered).
- **Allura Dental** — PCP Corporates' client; a real, operating practice. Principal dentist **Dr Sumaiya Pathan** (10+ years Australian clinical experience).
- **Non-negotiable compliance rule:** the individual owner's personal identity must **never** appear in Allura's org structure or public-facing content. Framing is always "PCP Corporates provides services to Allura Dental." (ATO PSI / related-party reasons.) Keep this in mind when writing any "who runs this" copy — reference **Allura Dental** or **PCP Corporates**, never a named individual.

**Practice facts** (safe to reuse): 22 Bradshaw Street, Truganina VIC 3029 · 03 8342 8888 · info@alluradental.com.au · alluradental.com.au · @allura_dental · ABN 74 984 835 963. Hours Mon–Fri 9–6, Sat 9–4, Sun closed. Service area: Truganina · Williams Landing · Point Cook · Tarneit · Hoppers Crossing · Laverton · Wyndham Vale · Altona.

**Signature offer:** $199 New Patient Offer (comprehensive exam, 2× X-rays, oral cancer screening, fluoride, full clean & polish, full-mouth 3D scan, oral care kit). CDBS accepted for eligible children.

### Sources this system was built from

All provided as uploaded HTML/Markdown (no live codebase or Figma link):

- `uploads/Allura-Dental-Project-Brief.md` — consolidated handoff brief (business facts, locked decisions, working notes).
- `uploads/Allura-Dental-Brand-Kit.html` — logo gallery (all lockups + reversed sets), both colour palettes, typography, voice, 8-variant circular badge gallery. **Logo/badge PNGs were extracted from this file into `assets/`.**
- `uploads/Allura-Dental-Website-Design-Guide.html` — sitemap, header/footer, full visual design system (logo matrix, icons, buttons, elevation, nav, Sticky CTA Bar, WhatsApp button), page-by-page content, Teeth Whitening treatment template. **Icon SVGs were extracted from this file into `assets/icons/`.** Site structure is adapted from the reference site *y3smiles.com*.
- `uploads/Allura-Dental-Values-Philosophy-Principles.html` — locked Values / Philosophy / Behaviours / 8 Operating Principles framework (source for staff-training and commitment copy).

> Everything in those files is considered **locked** unless a newer instruction overrides it. The `/badges/*.svg` true-vector folder referenced in the brief was **not** attached — the badges here are the raster PNGs extracted from the Brand Kit. See CAVEATS.

---

## CONTENT FUNDAMENTALS — how Allura writes

- **Voice:** warm, plain-spoken, and quietly confident. Trust is the throughline — the brand earns it rather than claims it. Reads like a careful, honest clinician talking to a real family, not a marketing department.
- **Person & address:** second person, **"you" / "your family"**-first; the practice is **"we / us"**. Example: *"honesty in every recommendation, quality in every treatment, and genuine care for your family's long-term oral health."*
- **Casing:** sentence case for headlines and body. Small UPPERCASE only for eyebrows, tags, and button labels (letter-spaced). Australian English spelling (*colour, personalised, optimise*).
- **Tone rules of thumb:** benefits before features; local and specific (name the suburbs) where it aids trust and SEO; never salesy or fear-based. No hype adjectives stacked up.
- **Emoji:** **none.** Not part of the brand voice anywhere on web or print.
- **Two register modes:**
  - *SEO/homepage* — location and service keywords woven in naturally: *"The trusted family dentist in Truganina, putting values into action."*
  - *Emotional/connection pages* — the warmer, non-keyword version from the Brand Kit voice reference.
- **Signature lines:** Primary — "Modern dentistry, done differently." Subline — "A new-age dentistry that you can see and experience."
- **Compliance guardrails (apply to ALL copy):**
  - Never say **"sterile-grade."** Compliant phrasing: *"a higher standard for infection control shaped by expert consultation with a strong cleanroom background."*
  - Every 10%-discount claim carries, verbatim: *"10% discount applies to services requiring gap or full payment. Not applicable to bulk-billed or health fund covered services."*
  - **CDBS** is a Medicare entitlement, never a "deal" — never stack cash discounts onto it.
  - Before/after imagery needs documented patient consent. Comparison-price claims need a substantiated itemised breakdown.
  - Check new marketing copy against **Principle 1** (recommendations never revenue-driven — explaining the *full* range of options, essential to ideal, *is* the honesty) and **Principle 5** (compliance overrides marketing convenience).

---

## VISUAL FOUNDATIONS

**Colour.** Two live palettes. **Option B (neutral-dominant) is the default:** Warm White `#FDFCFA`, Soft Beige `#F3EDE3`, Light Grey `#E7E3DB`, with Brushed Gold `#B8965A` / Deep Gold `#8F7038` as accents, Sage Green `#6A7F62` for small accents (icons/dividers), and Monument Charcoal `#323233` for *structural framing only*. **Option A (green-dominant)** uses Forest Green `#3F632F` (sampled from the real logo) as the field colour — existing print/flyers and the brand mark. An **extended palette** (Premium Beige `#FBF9F4`, Hog Bristle, Shale Grey, Moss Olive, Vibrant Gold `#CEB04E`, Deep Bronze, Pure Black) is used **1–2 tones at a time, never all at once**.

- **Black vs Monument rule (site-wide):** think physical space. **Monument Charcoal** = structural/architectural framing (document covers, dark logo backdrops) — reserved, rare. **Black** = anything that behaves like text (buttons, nav links, icons, headings, body). In practice almost everything on the site is **Black**; don't default to Monument for body or buttons.
- **What the colours mean:** each colour independently expresses Honesty, Quality *and* Care (not one-value-per-colour). Forest Green's steadiness/depth/calm; Gold's restraint (used in exactly one real place — the backlit reception sign), its "gold standard" meaning, its warmth.
- **Imagery vibe:** warm, natural-light, candid real-clinic photography (reception, treatment rooms with the pyramid skylights, CBCT machine, Dr Sumaiya's portrait, warm oak cabinetry). **Never** generic stock models "smiling at camera," and never the owner's face in patient-facing imagery.

**Type.** Content system is **Literata** (serif — headlines, quotes, considered/emotional content) + **Manrope** (sans — body, buttons, prices, disclaimers, anything functional). Rule of thumb: *button/price/disclaimer → Manrope; headline/quote → Fraunces.* **Poppins** is the **logo wordmark only** (ALLURA Bold / DENTAL Medium / TRUGANINA Light) — never content. Caveat/Fredoka are Instagram-carousel-cover only and are **not** part of the web system.

**Spacing & layout.** 4-based spacing scale (4 / 8 / 12 / 16 / 24 / 32 / 48 / 80). Sticky header with the Horizontal logo (desktop) / Tertiary stack (mobile), gaining a **hairline bottom border on scroll — never a shadow**. Content max-width \~1200px. Logos are sized by **icon-anchored** rule: match the tooth icon's actual rendered size across surfaces, not the container height.

**Corners, borders, elevation.** **4px radius throughout** ("architectural" — never rounded pills). Circles only for badges and the floating button. **Elevation rule:** no ambient drop shadows on static content — separation is a **1px hairline `#E7E3DB` border** only. The *single* exception is interactive elements, which may take a barely-there `0 2px 6px rgba(0,0,0,0.06)` hover lift to signal responsiveness; the sticky bar's top edge and the floating button carry their own functional shadows (`0 -2px 10px .08` / `0 2px 8px .18`).

**Motion.** Restrained. Calm, short eases (`cubic-bezier(.4,0,.2,1)`, \~120–320ms) — quiet fades and small lifts. **No bounce, no flashy transitions.**

**States.** Hover: primary button deepens gold (`#B8965A → #8F7038`); links go from black to deep gold; cards get the subtle lift only if interactive; ghost links reduce opacity slightly. Press: a 1px downward nudge (`translateY(1px)`) — no scale-down, no colour flash.

**Transparency & blur.** Effectively unused — the aesthetic is flat, opaque, and honest (matches the print heritage). No glassmorphism, no gradient washes, no glow.

---

## ICONOGRAPHY

Two tiers, both real to the brand and copied verbatim into `assets/icons/` (do **not** redraw them):

- **Tier 1 — Outline (default, everywhere):** thin-stroke (1.5px) outline icons on a 24×24 grid, stroked **Sage Green `#6A7F62`**, round caps/joins — a Feather/Lucide-adjacent house style. 17 named glyphs: booking, hours, check-up-tooth, whitening, aligners, fillings, crowns-and-bridges, implants, family-kids, 3d-scan-x-ray, emergency, treatment-plan, payment, phone, location, team, reviews. Plus utility icons added for UI needs: chat, menu, arrow-right, chevron-down, email, check.
- **Tier 2 — Colour badges (rare, special only):** filled circles from the extended palette with a white (or black-on-gold) stroked glyph — homepage highlight moments or one deliberately bold content piece, never the default. Stored in `assets/icons/badges/` (booking, care, technology, trust, family, comfort).

**Delivery:** consume icons through the **`Icon`** React component (paths inlined, so no fetch dependency) — `<Icon name="booking" />`. The raw SVGs also live in `assets/icons/` for static HTML use. **Emoji are never used** as icons; no icon font; no Unicode-glyph icons. When a needed glyph doesn't exist, add it in the same 1.5px sage outline style rather than importing a foreign icon set.

---

## Components

Reusable React primitives (import via `window.AlluraDentalDesignSystem_4aca76`). Grouped under `components/`:

**core/**

- **Button** — primary (Brushed Gold) / secondary (charcoal outline) / ghost (gold underlined link); sm·md·lg; optional icons.
- **Card** — static hairline-bordered container (no shadow); `interactive` opts into the hover lift.
- **Tag** — small uppercase category / eyebrow chip (gold / sage / green / neutral tones).
- **Icon** — the Tier-1 icon set by name (sage default, size/colour overridable).

**brand/**

- **TrustBadge** — hero trust-row item (sage icon + short reassurance line).
- **SealBadge** — circular stamp/seal from the 8 real badge assets (footer seal, merch, social).
- **StickyCTABar** — mobile bottom bar: gold "Book Online" (primary) + neutral "Call" (secondary), weighted by function.
- **WhatsAppButton** — floating circular Forest-Green chat button (generic chat-bubble icon, *not* the WhatsApp mark).

**Intentional additions** (no direct counterpart in the source, added because the system needs them): **Icon** (a React wrapper over the brand's own glyph set), **Card**, **Tag**, **TrustBadge** — all directly implied by the website design guide's card/badge/chip patterns. Header/footer/hero are provided as UI-kit compositions rather than primitives.

---

## UI kits

- **`ui_kits/website/`** — recreation of the Allura Dental marketing website (structure adapted from y3smiles.com): interactive header + mobile nav, homepage (hero, trust row, offer, why-us, service areas), treatments listing, a treatment detail page (Teeth Whitening template), and contact — with the sticky CTA bar and floating WhatsApp button. `index.html` is a click-through of these screens.

No slide template was provided, so no sample slides were created.

---

## Index / manifest (root)

- `styles.css` — **the** global entry point consumers link (imports the token + font + base files only).
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`, `base.css`.
- `assets/logos/` — 9 logo lockups (primary, secondary, tertiary, icon, stacked, horizontal, horizontal-wide, wordmark-gold, icon-white).
- `assets/badges/` — 10 circular badge PNGs.
- `assets/icons/` — 23 Tier-1 + utility SVGs; `assets/icons/badges/` — 6 Tier-2 colour badges.
- `components/core/`, `components/brand/` — the React primitives above (each with `.jsx` + `.d.ts` + `.prompt.md` + a demo card).
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.
- `ui_kits/website/` — the marketing-site recreation.
- `thumbnail.html` — the homepage tile. `SKILL.md` — Agent-Skills wrapper.

---

## CAVEATS

- **Fonts are loaded from Google Fonts** (Literata, Manrope, Poppins) via `@import` in `tokens/fonts.css` — no local font binaries were provided. These are the genuine specified families, but if brand-exact hinting/subsetting matters, supply the licensed binaries and I'll self-host them with real `@font-face` rules.
- **Badges are raster PNGs** extracted from the Brand Kit HTML, not the true-vector `/badges/*.svg` set the brief references (that folder wasn't attached). Attach the SVGs and I'll swap them in for crisp scaling.
- **Logos are PNGs** extracted from the source documents (no source vector/SVG logo was provided). Fine for web at rendered sizes; attach vector originals for large-format/print use.
- Photography is referenced but **not included** — the system uses no stock imagery by design. Drop real clinic photos into `assets/` and I'll wire them into the UI kit.
